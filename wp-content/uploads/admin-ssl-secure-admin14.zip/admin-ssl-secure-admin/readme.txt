=== Admin SSL ===
Contributors: blenjee, haris
Tags: secure login, shared ssl, security, ssl, private ssl, secure admin, login, admin, administration
Requires at least: 2.2
Tested up to: 2.7
Stable tag: 1.4


== Description ==

Admin SSL secures login page, admin area, posts, pages - whatever you want - using Private or Shared SSL.
Once you have activated the plugin please go to the Admin SSL config page to enable SSL, and
read the [installation instructions](http://www.kerrins.co.uk/blog/admin-ssl/setup/).

Each time you update Admin SSL, please read the [FAQ](http://www.kerrins.co.uk/blog/admin-ssl/faq/)
and [installation instructions](http://www.kerrins.co.uk/blog/admin-ssl/setup/) in
case there is some important information relating to the update.

Features:

1. Forces SSL on all pages where passwords can be entered.
2. Works with both Private and Shared SSL.
3. Can be installed on WordPress MU to force SSL across all blogs (only works if
you have a Private SSL certificate installed) from WPMU 1.3 upwards.
4. Custom additional URLS (e.g. wp-admin/) can be secured through the config page.
5. You can choose where you want the Admin SSL config page to appear!
6. Works on WordPress 2.2 - 2.7; it will not work on previous versions.


== Installation ==

Upload the Admin SSL directory to your plugins folder, enable the plugin and define
your options using the Config Page (under the Plugins menu).  Please make sure you 
set your Shared SSL URL correctly, or you will render your blog admin pages inaccessible.

For complete installation instructions for all versions of WordPress (including
WordPress MU), please go [here](http://www.kerrins.co.uk/blog/admin-ssl/setup/).


== Frequently Asked Questions ==

For the latest FAQ, please go [here](http://www.kerrins.co.uk/blog/admin-ssl/faq/).

If you experience any problems using this plugin, please read the
[FAQ](http://www.kerrins.co.uk/blog/admin-ssl/faq/) before posting a comment on the
[plugin homepage](http://www.kerrins.co.uk/blog/admin-ssl/).


== Screenshots ==

1. Secure login screen.
2. Secure plugins screen, with Admin SSL enabled.
