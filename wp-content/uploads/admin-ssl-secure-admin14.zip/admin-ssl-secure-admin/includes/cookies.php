<?php
/**
 * includes/cookies.php
 *
 * Handles cookies
 *
 * Author: BCG
 *
 */

//
//	hold cookie information globally
//

	$cookie_value = false;
	$cookie_expire = false;

//
//	return 'path' part of $shared_url for a cookie, or COOKIE_PATH for Private SSL
//

	function as_cookie_path()
	{
		global $use_shared,$shared_url;

		if($use_shared)
		{
			$url = parse_url($shared_url);
			return(rtrim($url["path"],"/")."/");
		}
		else return(COOKIE_PATH);
	}

//
//	set shared SSL auth cookies
//

	function as_set_auth_cookie($cookie,$expire=false)
	{
		global $cookie_value,$cookie_expire,$use_shared;

		$cookie_value = $cookie;
		$cookie_expire = $expire;

		as_log("as_set_auth_cookie()\nSetting auth cookie with path: ".as_cookie_path()."
			value: $cookie_value
			expire: $cookie_expire");

	//
	//	set cookies - if using Shared SSL as_cookie_path() gives the path part of $shared_url,
	//	if using Private SSL it is the same as COOKIE_PATH
	//

		setcookie(AUTH_COOKIE,$cookie_value,$cookie_expire,as_cookie_path(),COOKIE_DOMAIN);
		if($use_shared) as_siteurl_cookie("set");
	}

//
//	clear shared SSL auth cookies
//

	function as_clear_auth_cookie()
	{
		global $use_shared;

		as_log("as_clear_auth_cookie()\nClearing auth cookie with path: ".as_cookie_path());

	//
	//	set cookies - if using Shared SSL as_cookie_path() gives the path part of $shared_url,
	//	if using Private SSL it is the same as COOKIE_PATH
	//

		setcookie(AUTH_COOKIE," ",1,as_cookie_path(),COOKIE_DOMAIN);
		if($use_shared) as_siteurl_cookie("clear");
	}

//
//	sets or clears siteurl cookie
//

	function as_siteurl_cookie($action)
	{
		global $cookie_value,$cookie_expire,$dir,$plugins_dir,$secure_url;

	//
	//	continue only if action is 'set' and there is a cookie value,
	//	or if action is 'clear'
	//

		$continue = false;

		if($action === "set" && $cookie_value) $continue = true;
		elseif($action === "clear")
		{
			$cookie_value = " ";
			$cookie_expire = 1;
			$continue = true;
		}

	//
	//	redirect to cookie script - only ever called from wp-login.php
	//

		if($continue)
		{
			$path = "/wp-content/$plugins_dir/$dir/admin-ssl-cookie.php";
			$file = str_replace("/wp-login.php","",$_SERVER["SCRIPT_FILENAME"]).$path;

			as_log("as_siteurl_cookie()\nPath to admin-ssl-cookie.php: $file");

			if(file_exists($file))
			{
			//
			//	build the URL to redirect to after setting the cookie
			//

				if(redirect_to() && redirect_to() !== "wp-admin/")
				{
					if(strpos(redirect_to(),"http") === 0) $redirect = redirect_to();
					elseif(strpos(redirect_to(),"/") === 0) $redirect = scheme($use_ssl).host().redirect_to();
					else $redirect .= $secure_url."/".redirect_to();
				}
				else $redirect = $secure_url."/wp-login.php";

			//
			//	build the URL to admin-ssl-cookie.php with the cookie data
			//

				$location = rtrim(get_option("siteurl"),"/");
				$location .= "$path?name=".AUTH_COOKIE."&value=$cookie_value";
				$location .= "&expire=$cookie_expire&path=".COOKIEPATH."&domain=".COOKIE_DOMAIN;
				$location .= "&redirect=".urlencode($redirect);

				as_log("as_siteurl_cookie()\nRedirecting to: $location");
				as_redirect($location);
			}
		}
	}
?>