<?php
/**
 * includes/wp-2.5-auth-cookie.php
 *
 * Replace WP 2.6 cookie code so Admin SSL works well
 *
 * Author: BCG
 *
 */

//
//	WordPress 2.5.1 cookie code
//

if ( !function_exists('wp_validate_auth_cookie') ) :
/**
 * wp_validate_auth_cookie() - Validates authentication cookie
 *
 * The checks include making sure that the authentication cookie
 * is set and pulling in the contents (if $cookie is not used).
 *
 * Makes sure the cookie is not expired. Verifies the hash in
 * cookie is what is should be and compares the two.
 *
 * @since 2.5
 *
 * @param string $cookie Optional. If used, will validate contents instead of cookie's
 * @return bool|int False if invalid cookie, User ID if valid.
 */
function wp_validate_auth_cookie($cookie = '') {
	if ( empty($cookie) ) {
		if ( empty($_COOKIE[AUTH_COOKIE]) )
			return false;
		$cookie = $_COOKIE[AUTH_COOKIE];
	}

	$cookie_elements = explode('|', $cookie);
	if ( count($cookie_elements) != 3 )
		return false;

	list($username, $expiration, $hmac) = $cookie_elements;

	$expired = $expiration;

	// Allow a grace period for POST and AJAX requests
	if ( defined('DOING_AJAX') || 'POST' == $_SERVER['REQUEST_METHOD'] )
		$expired += 3600;

	// Quick check to see if an honest cookie has expired
	if ( $expired < time() )
		return false;

	$key = wp_hash($username . '|' . $expiration);
	$hash = hash_hmac('md5', $username . '|' . $expiration, $key);

	if ( $hmac != $hash )
		return false;

	$user = get_userdatabylogin($username);
	if ( ! $user )
		return false;

	return $user->ID;
}
endif;

if ( !function_exists('wp_generate_auth_cookie') ) :
/**
 * wp_generate_auth_cookie() - Generate authentication cookie contents
 *
 * @since 2.5
 * @uses apply_filters() Calls 'auth_cookie' hook on $cookie contents, User ID
 *		and expiration of cookie.
 *
 * @param int $user_id User ID
 * @param int $expiration Cookie expiration in seconds
 * @return string Authentication cookie contents
 */
function wp_generate_auth_cookie($user_id, $expiration) {
	$user = get_userdata($user_id);

	$key = wp_hash($user->user_login . '|' . $expiration);
	$hash = hash_hmac('md5', $user->user_login . '|' . $expiration, $key);

	$cookie = $user->user_login . '|' . $expiration . '|' . $hash;

	return apply_filters('auth_cookie', $cookie, $user_id, $expiration);
}
endif;

if ( !function_exists('wp_set_auth_cookie') ) :
/**
 * wp_set_auth_cookie() - Sets the authentication cookies based User ID
 *
 * The $remember parameter increases the time that the cookie will
 * be kept. The default the cookie is kept without remembering is
 * two days. When $remember is set, the cookies will be kept for
 * 14 days or two weeks.
 *
 * @since 2.5
 *
 * @param int $user_id User ID
 * @param bool $remember Whether to remember the user or not
 */
function wp_set_auth_cookie($user_id, $remember = false) {
	if ( $remember ) {
		$expiration = $expire = time() + 1209600;
	} else {
		$expiration = time() + 172800;
		$expire = 0;
	}

	$cookie = wp_generate_auth_cookie($user_id, $expiration);

	do_action('set_auth_cookie', $cookie, $expire);

	setcookie(AUTH_COOKIE, $cookie, $expire, COOKIEPATH, COOKIE_DOMAIN);
	if ( COOKIEPATH != SITECOOKIEPATH )
		setcookie(AUTH_COOKIE, $cookie, $expire, SITECOOKIEPATH, COOKIE_DOMAIN);
}
endif;

if ( !function_exists('wp_clear_auth_cookie') ) :
/**
 * wp_clear_auth_cookie() - Deletes all of the cookies associated with authentication
 *
 * @since 2.5
 */
function wp_clear_auth_cookie() {
	setcookie(AUTH_COOKIE, ' ', time() - 31536000, COOKIEPATH, COOKIE_DOMAIN);
	setcookie(AUTH_COOKIE, ' ', time() - 31536000, SITECOOKIEPATH, COOKIE_DOMAIN);

	// Old cookies
	setcookie(USER_COOKIE, ' ', time() - 31536000, COOKIEPATH, COOKIE_DOMAIN);
	setcookie(PASS_COOKIE, ' ', time() - 31536000, COOKIEPATH, COOKIE_DOMAIN);
	setcookie(USER_COOKIE, ' ', time() - 31536000, SITECOOKIEPATH, COOKIE_DOMAIN);
	setcookie(PASS_COOKIE, ' ', time() - 31536000, SITECOOKIEPATH, COOKIE_DOMAIN);
}
endif;

?>