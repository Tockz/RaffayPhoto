<?php
/**
 * admin-ssl-cookie.php
 *
 * Admin SSL cookie script
 * Adds a site-side cookie, for use in Shared SSL setups
 *
 * Author: BCG
 *
 */

//
//	get cookie data
//

	$name = $_GET["name"];
	$value = $_GET["value"];
	$expire = $_GET["expire"];
	$path = $_GET["path"];
	$domain = $_GET["domain"];

	if(!$expire || $expire === 1) $expire = 0;

	if($value === " ")
	{
	//
	//	include WordPress configuration file
	//

		define("ADMIN_SSL_DO_NOT_REDIRECT",true);

		$wp_config1 = "../../wp-config.php";
		$wp_config2 = "../../../wp-config.php";
		$wp_config3 = "../../../../wp-config.php";

		if(file_exists($wp_config1)) require_once($wp_config1);
		elseif(file_exists($wp_config2)) require_once($wp_config2);
		elseif(file_exists($wp_config3)) require_once($wp_config3);
		else exit("Unable to find WordPress configuration file.");

	//
	//	remove all cookies
	//

		setcookie(AUTH_COOKIE, ' ', time() - 31536000, ADMIN_COOKIE_PATH, COOKIE_DOMAIN);
		setcookie(SECURE_AUTH_COOKIE, ' ', time() - 31536000, ADMIN_COOKIE_PATH, COOKIE_DOMAIN);
		setcookie(AUTH_COOKIE, ' ', time() - 31536000, PLUGINS_COOKIE_PATH, COOKIE_DOMAIN);
		setcookie(SECURE_AUTH_COOKIE, ' ', time() - 31536000, PLUGINS_COOKIE_PATH, COOKIE_DOMAIN);
		setcookie(LOGGED_IN_COOKIE, ' ', time() - 31536000, COOKIEPATH, COOKIE_DOMAIN);
		setcookie(LOGGED_IN_COOKIE, ' ', time() - 31536000, SITECOOKIEPATH, COOKIE_DOMAIN);

		// Old cookies
		setcookie(AUTH_COOKIE, ' ', time() - 31536000, COOKIEPATH, COOKIE_DOMAIN);
		setcookie(AUTH_COOKIE, ' ', time() - 31536000, SITECOOKIEPATH, COOKIE_DOMAIN);
		setcookie(SECURE_AUTH_COOKIE, ' ', time() - 31536000, COOKIEPATH, COOKIE_DOMAIN);
		setcookie(SECURE_AUTH_COOKIE, ' ', time() - 31536000, SITECOOKIEPATH, COOKIE_DOMAIN);

		// Even older cookies
		setcookie(USER_COOKIE, ' ', time() - 31536000, COOKIEPATH, COOKIE_DOMAIN);
		setcookie(PASS_COOKIE, ' ', time() - 31536000, COOKIEPATH, COOKIE_DOMAIN);
		setcookie(USER_COOKIE, ' ', time() - 31536000, SITECOOKIEPATH, COOKIE_DOMAIN);
		setcookie(PASS_COOKIE, ' ', time() - 31536000, SITECOOKIEPATH, COOKIE_DOMAIN);

	//
	//	set redirect variable
	//

		$redirect = true;
	}
	else $redirect = setcookie($name,$value,$expire,$path,$domain);

	if($redirect)
	{
		$redirect = $_GET["redirect"].($value === " " ? "?loggedout=true" : "");
		header("location: $redirect");
	}
	else
	{
		$msg = "\n\nUnable to set siteurl cookie:
			name: $name
			value: $value
			expire: $expire
			path: $path
			domain: $domain";
		error_log($msg,3,"./cookie-error.log");
	}

?>