<?php
/*
Plugin Name: Admin SSL
Plugin URI: http://www.kerrins.co.uk/blog/admin-ssl/
Description: Secures any WordPress URL using Private or Shared SSL. Once the plugin is activated go to the Admin SSL config page to enable SSL and read the <a href="http://www.kerrins.co.uk/blog/admin-ssl/setup/">installation instructions</a>.
Author: BCG
Version: 1.4
Date: 2009-02-10 21:21
Author URI: http://www.kerrins.co.uk/

For changelog please see release-notes.txt

*/

//
//	if you are experiencing problems, set this to 'true' and messages will be logged
//	in the Admin SSL directory (usually /wp-content/plugins/admin-ssl/debug.log
//

	define("DEBUG",false);

//
//	if this is 'true' then the database will be updated with the default options - use if
//	you cannot access admin-ssl-reset.php after setting wrong Shared SSL settings
//	you MUST change back to false after resetting, or you will not be able to enable SSL
//

	define("RESET",false);

/*																							*
 *																							*
 * 																							*
 * 																							*
 * 			DO NOT EDIT BELOW THIS LINE - USE THE CONFIG PAGE TO CHANGE SETTINGS			*
 * 																							*
 * 																							*
 * 																							*
 * 																							*
 */


//
//	requires $wp_version check - this plugin WILL BREAK earlier versions of WordPress and WPMU
//

	if(isset($wp_version) && strpos($wp_version,"wordpress-mu") === false && $wp_version >= 2.2)
	{
	//
	//
	//	DEBUG MODE AND FUNCTIONS
	//
	//

		if(!defined("TEST") || $first_test):

		//
		//	log debug messages to plugin operating directory
		//

			function as_log($msg)
			{
				global $path,$slash;

				$msg = preg_replace('/\t/',"",$msg);

				if($path && $slash && DEBUG)
					error_log($msg."\n\n",3,$path.$slash."debug.log");
				elseif(@TEST && DEBUG)
					echo("\n$msg");
			}

		//
		//	display message on admin pages if debug or reset are enabled
		//

			function as_warning()
			{
				global $path,$slash;

				if(DEBUG)
					echo('
						<div id="admin-ssl-debug-warning" class="error fade">
							<p><strong>Admin SSL</strong> is currently debugging to: '.$path.$slash.'debug.log</p>
						</div>
					');

				if(RESET)
					echo('
						<div id="admin-ssl-reset-warning" class="error fade">
							<p><strong>Admin SSL</strong> is currently in reset mode - you will not
							be able to secure your site with SSL until you disable reset mode.</p>
						</div>
					');
			}

		//
		//	shorthands for lazy people
		//

			function host(){ # returns HTTP_HOST with any port numbers removed
				return(preg_replace('/:.+$/',"",$_SERVER["HTTP_HOST"])); }
			function is_https(){ # return true or false, HTTPS enabled
				global $https_key,$https_value;
				return(isset($_SERVER[$https_key]) && $https_value === $_SERVER[$https_key] ? true : false); }
			function _post($key){ # safely return escaped value from $_POST array
				return(isset($_POST[$key]) ? attribute_escape($_POST[$key]) : null); }
			function redirect_to(){ # return WordPress' redirect_to
				return(isset($_REQUEST["redirect_to"]) ? attribute_escape($_REQUEST["redirect_to"]) : ""); }
			function req_uri(){ # return server request uri
				return($_SERVER["REQUEST_URI"]); }
			function scheme($use_https){ # return scheme based on test value
				return(($use_https ? "https" : "http")."://"); }
			function user_can($what){ # checks if function exists before calling it
				return(function_exists("current_user_can") ? current_user_can($what) : false); }

		//
		//	safe redirect function - don't want to use wp_redirect()
		//

			function as_redirect($location)
			{
				if((!defined("TEST") || $first_test) && !defined("ADMIN_SSL_DO_NOT_REDIRECT"))
				{
					session_write_close();
					header("location: $location");
					exit;
				}
				elseif(TEST) return($location);
			}

		//
		//	get the Apache version
		//

			function apache_version($test=null, $precision=0)
			{
				$re = "/Apache\/([\d.]+)/";
				preg_match($re, $_SERVER["SERVER_SOFTWARE"], $matches);
				$version = $matches[1];

				if(is_null($test)) return(doubleval($version));
				else return(round($version, $precision) == $test ? true : false);
			}

		endif;

	//
	//
	//	OPERATING DIRECTORY AND WPMU DETECTION
	//
	//

		//
		//	get operating directory and log environment variables
		//

			$slash = strpos(__FILE__,"/") === false ? "\\" : "/";
			$path = str_replace($slash."admin-ssl.php","",__FILE__);
			$dir = substr($path,strrpos($path,$slash)+1);

			as_log("### ADMIN SSL BEGINS ###");
			as_log("HTTP Host: ".host()."
				Request URI: ".req_uri()."
				Redirect to: ".redirect_to()."
				Found admin-ssl.php in
				 - path: $path
				 - directory: $dir");

		//
		//	if operating directory is mu-plugins, get the name of admin-ssl directory
		//

			$plugins_dir = "plugins";
			$config_page = $wp_version < 2.5 ? "config-page-old.php" : "config-page.php";

			if($dir === "mu-plugins")
			{
				$d_mu_plugins = dir($path);
				$tmp = "";

			//
			//	loop through the main plugins directory
			//

				while(false !== ($plugin_dir = $d_mu_plugins->read()))
				{
					if($plugin_dir !== "." && $plugin_dir !== "..")
					{
					//
					//	build the path to each entry - if it is a subfolder, open it
					//

						$plugin_path = $path.$slash.$plugin_dir;

						if(is_dir($plugin_path))
						{
							$d_plugin = dir($plugin_path);

						//
						//	loop through each item in this subfolder, searching for $config_page
						//

							while(false !== ($entry = $d_plugin->read()))
							{
								if(is_file($plugin_path.$slash.$entry) && $entry === "readme.txt")
								{
									$tmp = $plugin_dir;
									break(2);
								}
							}
						}
					}
				}

			//
			//	if the loop finds the config file it saves the directory as $tmp and breaks the loop
			//

				if($tmp)
				{
					$dir = $tmp;
					$plugins_dir = "mu-plugins";
					$config_parent = "wpmu-admin.php";

					as_log("Using WPMU - Admin SSL directory changed to: $dir");
				}
			}

		//
		//	function returns true if WPMU has been detected
		//

			if(!defined("TEST") || $first_test):

			function is_wpmu()
			{
				global $plugins_dir;
				return($plugins_dir === "mu-plugins" ? true : false);
			}

			function wpmu_dir(){ # returns the operating directory if on WPMU
				global $dir,$slash;
				return(is_wpmu() ? $dir.$slash : "");
			}

			endif;

		//
		//	log variables just defined
		//

			as_log("Plugins directory: $plugins_dir
				Config page: $config_page
				Is WPMU: ".(is_wpmu() ? "Yes" : "No"));

	//
	//
	//	GET (OR SET DEFAULT) OPTIONS
	//
	//

		require_once(wpmu_dir()."includes/options.php");

	//
	//
	//	ADD PLUGIN ACTION LINKS
	//
	//

		function as_action_links($links, $file)
		{
			static $this_plugin;
			if(!$this_plugin) $this_plugin = plugin_basename(__FILE__);

			global $config_parent,$config_page_ref;

			if($file === $this_plugin)
			{
				$settings_link = '<a href="'.$config_parent.'?page='.$config_page_ref.'">'._("Settings")."</a>";
				array_unshift($links, $settings_link);
			}

			return($links);
		}

	//
	//
	//	THIS IS WHERE THE REAL STUFF BEGINS...
	//
	//

		if(!defined("TEST") || $first_test):

		//
		//
		//	WORDPRESS HOOKS - CHECKING HTTP/HTTPS
		//
		//

			require_once(wpmu_dir()."includes/https.php");

		//
		//
		//	WORDPRESS HOOKS - CONFIGURATION
		//
		//

			require_once(wpmu_dir()."includes/config.php");

		//
		//
		//	WORDPRESS HOOKS - COOKIE HANDLING
		//
		//

			require_once(wpmu_dir()."includes/cookies.php");

		//
		//
		//	ADD WORDPRESS HOOKS
		//
		//

			require_once(wpmu_dir()."includes/hooks.php");

		//
		//
		//	REPLACE WP 2.6 COOKIE CODE
		//
		//

			require_once(wpmu_dir()."includes/wp-2.5-auth-cookies.php");

		endif;
	}

?>